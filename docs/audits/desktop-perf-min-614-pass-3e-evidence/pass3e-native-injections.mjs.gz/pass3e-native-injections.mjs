import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import {readFile,writeFile} from 'node:fs/promises';
import {chromium} from 'playwright';
const out='output/playwright/performance', original=JSON.parse(await readFile(`${out}/pass3e-personal-initial.json`,'utf8'));
const b=await chromium.connectOverCDP('http://127.0.0.1:9341'),ctx=b.contexts()[0],page=ctx.pages()[0];
const targets=[339,342,344].map(number=>original.prs.pullRequests.find(pr=>pr.pr_number===number&&pr.pr_url===`https://github.com/mangue-dev/minddy/pull/${number}`));assert.ok(targets.every(Boolean));
const hrefs=['/home','/all','/statistics','/routines','/inbox','/trash','/settings',original.tabs[2].href,`/pull-requests?pr=${targets[0].prId}`,original.tabs[4].href,`/pull-requests?pr=${targets[1].prId}`,`/pull-requests?pr=${targets[2].prId}`];
let tabs=hrefs.map((href,position)=>({...original.tabs[0],id:randomUUID(),href,position,pinned:false,custom_name:`MIN-614 local ${position}`,revision:1}));
const report={sha:'061615eaea1e815c4b29d4cb842816a4c7a64ee2',definition:'Separate injected native diagnostics. Twelve virtual tab rows; real GitHub reads; navigation writes intercepted in memory. No remote forge mutation.',visits:[],states:[],blockedWrites:[],cleanup:false};
const save=()=>writeFile(`${out}/pass3e-native-injections.json`,JSON.stringify(report,null,2));
let gate,arrive,release,held=0,injectedError=false;
const targetPath=`/api/pull-requests/${targets[1].prId}`;
const routeReads=[]; const responses=[];page.on('response',r=>{const path=new URL(r.url()).pathname;if(path.includes('/pull-requests/'))responses.push({path,status:r.status(),at:Date.now()});});const requests=[]; page.on('request',request=>{const u=new URL(request.url());if(u.pathname.startsWith('/api/')) requests.push({path:u.pathname,method:request.method(),at:Date.now()});});
await ctx.route('**/api/**',async route=>{
 const request=route.request(),u=new URL(request.url()),method=request.method();
 if(u.pathname.startsWith('/api/me/app-tabs')){
  const id=u.pathname.split('/')[4],body=method==='GET'?{}:request.postDataJSON();
  if(method==='GET'){routeReads.push({at:Date.now(),count:tabs.length});return route.fulfill({json:tabs});}
  if(method==='PATCH'){const tab=tabs.find(t=>t.id===id);assert.ok(tab);Object.assign(tab,body.patch,{revision:tab.revision+1});return route.fulfill({json:{tab}});}
  if(method==='POST'&&u.pathname==='/api/me/app-tabs'){const tab={...tabs[0],id:body.id,href:'/home',position:tabs.length,revision:1};tabs.push(tab);return route.fulfill({json:{tab}});}
  report.blockedWrites.push({path:u.pathname,method});await save();return route.abort();
 }
 if(method!=='GET'&&u.pathname!=='/api/me/local-snapshots'){report.blockedWrites.push({path:u.pathname,method});await save();return route.abort();}
 if(u.pathname===targetPath&&method==='GET'){
  if(injectedError) return route.fulfill({status:429,headers:{'Retry-After':'2'},json:{error:'MIN-614 local rate-limit injection'}});
  if(gate){held++;arrive?.();await gate;}
 }
 await route.continue();
});
const moreLabel="Plus d'onglets";
const active=()=>page;
const status=()=>active().getByTestId('pr-read-state');
async function select(index){const start=Date.now(),at=requests.length;const control=page.locator(`[data-app-tab-id="${tabs[index].id}"]`);if(await control.count())await control.click();else{await page.getByRole('button',{name:moreLabel,exact:true}).click();await page.getByRole('menuitem',{name:tabs[index].custom_name,exact:true}).click();}await page.waitForTimeout(120);report.visits.push({index,ms:Date.now()-start,requests:requests.slice(at),retainedRoots:await page.locator('[data-app-view-active]').count()});await save();}
async function settled(){await page.waitForFunction(()=>{const root=document;return root?.querySelector('[data-testid="pr-activity-timeline"]')&&!root.querySelector('[data-testid="pr-read-state"]');},{},{timeout:45000});}
try{
 await page.evaluate(()=>{for(const key of Object.keys(sessionStorage))if(key.startsWith('minddy.app-tabs.'))sessionStorage.removeItem(key);localStorage.removeItem('minddy.query-cache');localStorage.setItem('minddy.trace','1');});
 await page.goto(`http://localhost:3111${hrefs[10]}`,{waitUntil:'domcontentloaded'});await settled();
 await page.getByRole('button',{name:moreLabel,exact:true}).click();assert.equal(await page.getByRole('menuitem',{name:tabs[11].custom_name,exact:true}).count(),1);report.tabCount=tabs.length;await page.keyboard.press('Escape');await page.getByRole('menu').waitFor({state:'hidden'});await page.waitForTimeout(150);
 for(const index of [11,0,10]){await select(index);if([8,10,11].includes(index))await settled();}
 await select(11);await settled();
 gate=new Promise(resolve=>{release=resolve;});const arrived=new Promise(resolve=>{arrive=resolve;});
 await select(10);await arrived;
 assert.equal(await status().getAttribute('data-read-state'),'refreshing');
 await page.getByTestId('pr-readiness-control').click();
 const previous={name:'held-authority',state:await status().getAttribute('data-read-state'),timeline:await active().getByTestId('pr-activity-timeline').count(),mergeDisabled:await active().getByTestId('pr-readiness-merge').isDisabled(),held};report.states.push(previous);await save();
 assert.equal(previous.timeline,1);assert.ok(previous.mergeDisabled);
 await page.getByTestId('pr-readiness-control').click();gate=null;release();await settled();report.states.push({name:'authoritative-complete',statusAbsent:await status().count()===0});
 await select(11);await settled();injectedError=true;await select(10);await page.waitForFunction(()=>document.querySelector('[data-testid="pr-read-state"]')?.getAttribute('data-read-state')==='error',{},{timeout:15000});
 report.states.push({name:'rate-limited-cached',state:await status().getAttribute('data-read-state'),timeline:await active().getByTestId('pr-activity-timeline').count()});
 injectedError=false;await page.waitForTimeout(2200);await status().getByRole('button').click();await settled();report.states.push({name:'explicit-recovery',statusAbsent:await status().count()===0});
 const cdp=await ctx.newCDPSession(page);await cdp.send('Performance.enable');const before=await cdp.send('Performance.getMetrics');const start=requests.length;await page.waitForTimeout(15000);report.idle={ms:15000,requests:requests.slice(start),before,after:await cdp.send('Performance.getMetrics')};
 report.dom={definition:'No new PR DOM retention. Existing host root budget only; data remains in normal QueryClient.',roots:await page.locator('[data-app-view-active]').count()};
 assert.equal(report.blockedWrites.length,0);
}catch(error){report.error=String(error);report.failureState={readState:await status().getAttribute('data-read-state').catch(()=>null),text:await status().textContent().catch(()=>null),url:page.url()};throw error;}
finally{
 gate=null;release?.();await ctx.unroute('**/api/**');await page.goto(`http://localhost:3111${original.tabs[0].href}`,{waitUntil:'domcontentloaded'});
 const current=await page.evaluate(async()=> (await fetch('/api/me/app-tabs')).json());const fields=t=>({id:t.id,href:t.href,pinned:t.pinned,position:t.position,custom_name:t.custom_name});assert.deepEqual(current.map(fields),original.tabs.map(fields));
 report.responses=responses;report.routeReads=routeReads;report.requests=requests;report.cleanup=true;await save();await b.close();
}
